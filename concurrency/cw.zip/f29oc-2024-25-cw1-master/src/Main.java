
// v001 11/10/2024

public class Main {
	public static void main(String[] args) {
		Tests tests =  new Tests();

		System.out.println("\n\nUR1 EXAMPLE TEST:");
		tests.exampleUR1Test();

		System.out.println("\n\nUR2 EXAMPLE TEST:");
		tests.exampleUR2Test();	

		System.out.println("\n\nUR3 EXAMPLE TEST:");
		tests.exampleUR3Test();	

		System.out.println("\n\nUR4 4EXAMPLE TEST:");
		tests.exampleUR4Test();	

		System.out.println("\n\nUR5 EXAMPLE TEST:");
		tests.exampleUR5test();

		System.out.println("\n\nUR6 EXAMPLE TEST:");
		tests.exampleUR6test();		
	}
}
